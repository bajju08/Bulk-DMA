
import os
import json
import time
import random
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials
import requests

SPREADSHEET_ID = "1vnrsybq4tX4BFvDupY5y8oxFLh0LyuPF_dm-viSqxWM"

BULK_HEADERS = [
    'DATE', 'SYMBOL', 'SECURITY NAME', 'CLIENT NAME',
    'TYPE', 'QUANTITY', 'EXECUTION PRICE',
    'VALUE (₹ CR)', 'INSTITUTION_FLAG', 'SIZE INDEX', 'SIGNAL FIELD'
]

BLOCK_HEADERS = [
    'DATE', 'SYMBOL', 'SECURITY NAME', 'CLIENT NAME',
    'TYPE', 'QUANTITY', 'PRICE',
    'VALUE (₹ CR)', 'INSTITUTION_FLAG', 'INTERCEPT SIGNAL'
]

INSTITUTIONS = [
    'SBI MF', 'HDFC MF', 'ICICI PRUDENTIAL', 'KOTAK MF',
    'AXIS MF', 'MIRAE ASSET', 'NIPPON', 'DSP',
    'FRANKLIN', 'UTI MF', 'MOTILAL OSWAL',
    'MORGAN STANLEY', 'GOLDMAN SACHS', 'NOMURA',
    'CLSA', 'SOCIETE GENERALE', 'LIC', 'BLACKROCK'
]


def create_session():
    session = requests.Session()

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.nseindia.com/",
        "Connection": "keep-alive"
    }

    session.headers.update(headers)

    # Important: initialize cookies
    session.get("https://www.nseindia.com", timeout=20)
    time.sleep(2)

    return session


def fetch_nse_large_deals(deal_type="Bulk deals"):

    session = create_session()

    cache_buster = random.randint(10000, 99999)

    url = (
        "https://www.nseindia.com/api/"
        "historicalOR/bulk-block-short-deals"
        f"?dealType={deal_type}&_={cache_buster}"
    )

    print(f"Fetching URL: {url}")

    response = session.get(
        url,
        headers={
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://www.nseindia.com/report-detail/display-bulk-and-block-deals",
            "X-Requested-With": "XMLHttpRequest"
        },
        timeout=30
    )

    print("Status Code:", response.status_code)

    if response.status_code != 200:
        print("Response Text:", response.text[:500])
        return []

    try:
        data = response.json()
    except Exception as e:
        print("JSON parse failed:", str(e))
        print(response.text[:500])
        return []

    if isinstance(data, dict):
        return data.get("data", [])

    return []


def clear_and_reset_tab(worksheet, headers):

    worksheet.batch_clear(['A2:Z5000'])

    worksheet.update(
        range_name='A2',
        values=[headers],
        value_input_option='USER_ENTERED'
    )


def auth_google():

    creds_json = os.environ.get("GOOGLE_CREDS_SECRET")

    if not creds_json:
        raise Exception(
            "GOOGLE_CREDS_SECRET GitHub secret missing"
        )

    creds_dict = json.loads(creds_json)

    scope = [
        "https://spreadsheets.google.com/feeds",
        "https://www.googleapis.com/auth/drive"
    ]

    creds = Credentials.from_service_account_info(
        creds_dict,
        scopes=scope
    )

    client = gspread.authorize(creds)

    return client


def build_bulk_rows(data):

    rows = []

    for item in data:

        symbol = item.get('symbol', '')

        if not symbol:
            continue

        client_name = item.get('clientName', '—')
        buy_sell = str(item.get('buySell', '')).upper()

        qty = float(item.get('quantity', 0) or 0)
        price = float(item.get('price', 0) or 0)

        value_cr = round((qty * price) / 10000000, 2)

        is_inst = any(
            inst in client_name.upper()
            for inst in INSTITUTIONS
        )

        signal = (
            "🏛️ INST BUY ⭐"
            if is_inst and "BUY" in buy_sell
            else "🏛️ INST SELL ⚠️"
            if is_inst
            else "📊 POSITION ACCUMULATION"
        )

        rows.append([
            item.get('date', ''),
            f"NSE:{symbol}",
            item.get('name', '—'),
            client_name,
            "BUY" if "BUY" in buy_sell else "SELL",
            qty,
            price,
            value_cr,
            "YES" if is_inst else "—",
            "🟠 LARGE" if value_cr >= 50 else "⚪ MINOR",
            signal
        ])

    return rows


def build_block_rows(data):

    rows = []

    for item in data:

        symbol = item.get('symbol', '')

        if not symbol:
            continue

        client_name = item.get('clientName', '—')
        buy_sell = str(item.get('buySell', '')).upper()

        qty = float(item.get('quantity', 0) or 0)
        price = float(item.get('price', 0) or 0)

        value_cr = round((qty * price) / 10000000, 2)

        rows.append([
            item.get('date', ''),
            f"NSE:{symbol}",
            item.get('name', '—'),
            client_name,
            "BUY" if "BUY" in buy_sell else "SELL",
            qty,
            price,
            value_cr,
            "YES",
            "🧱 CONSOLIDATION CROSS"
        ])

    return rows


def main():

    print("Starting NSE Bulk/Block Sync")

    client = auth_google()

    sheet = client.open_by_key(SPREADSHEET_ID)

    # BULK
    bulk_data = fetch_nse_large_deals("Bulk deals")

    bulk_tab = sheet.worksheet("📦 Bulk Deals")

    clear_and_reset_tab(bulk_tab, BULK_HEADERS)

    bulk_rows = build_bulk_rows(bulk_data)

    if bulk_rows:
        bulk_tab.append_rows(
            bulk_rows,
            value_input_option='USER_ENTERED'
        )

    # BLOCK
    block_data = fetch_nse_large_deals("Block deals")

    block_tab = sheet.worksheet("🧱 Block Deals")

    clear_and_reset_tab(block_tab, BLOCK_HEADERS)

    block_rows = build_block_rows(block_data)

    if block_rows:
        block_tab.append_rows(
            block_rows,
            value_input_option='USER_ENTERED'
        )

    # DASHBOARD
    try:

        dashboard = sheet.worksheet("🎯 Platform Dashboard")

        sync_time = time.strftime(
            "%d %b %Y %H:%M:%S IST",
            time.localtime(time.time() + 19800)
        )

        dashboard.update(
            'A2',
            [[f"✅ Sync Successful | {sync_time}"]]
        )

    except Exception as e:
        print("Dashboard update skipped:", str(e))

    print("Pipeline completed successfully")


if __name__ == "__main__":
    main()
